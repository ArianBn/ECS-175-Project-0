'use strict';

import App from "./app/app.js"; 

/**
 * Entry point to the application
 */
function main() {
    const app = new App();
    app.start();
}

main();
