import { hex2rgb, deg2rad } from './js/utils/utils.js';

/**
 * @Class
 * Base class for all drawable shapes
 */
class Shape {
    constructor(gl, shader, vertices, indices, color, draw_mode, num_elements) {
        this.shader = shader;

        this.vertices = vertices;
        this.vertices_buffer = null;
        this.createVBO(gl);

        this.indices = indices;
        this.index_buffer = null;
        this.createIBO(gl);

        this.color = color;

        this.draw_mode = draw_mode;

        this.num_components = 2; // Each vertex has 2 components (x, y)
        this.num_elements = num_elements;

        this.vertex_array_object = null;
        this.createVAO(gl, shader);
    }

    createVAO(gl, shader) {
        this.vertex_array_object = gl.createVertexArray();
        gl.bindVertexArray(this.vertex_array_object);

        gl.bindBuffer(gl.ARRAY_BUFFER, this.vertices_buffer);
        let positionAttribLocation = gl.getAttribLocation(shader.program, 'a_position');
        gl.vertexAttribPointer(positionAttribLocation, this.num_components, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(positionAttribLocation);

        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.index_buffer);


        gl.bindVertexArray(null);
    }

    createVBO(gl) {
        this.vertices_buffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.vertices_buffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.vertices), gl.STATIC_DRAW);
    }

    createIBO(gl) {
        this.index_buffer = gl.createBuffer();
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.index_buffer);
        gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(this.indices), gl.STATIC_DRAW);
    }

    render(gl) {
        gl.bindVertexArray(this.vertex_array_object);
        this.shader.setUniform3f("u_color", new Float32Array(this.color));  // Ensure color is a Float32Array
        gl.drawElements(this.draw_mode, this.indices.length, gl.UNSIGNED_SHORT, 0);
        gl.bindVertexArray(null);
    }
}

/**
 * @Class
 * Triangle extension for Shape.
 */
class Triangle extends Shape {
    constructor(gl, shader, position, color, sideLength) {
        let cosangle = Math.cos(deg2rad(30));
        let sinangle = Math.sin(deg2rad(30));


        let vertices = [
            position[0], position[1] - sideLength / 2,   // Top vertex (upwards)
            position[0] - sideLength * cosangle, position[1] + sideLength * sinangle,  
            position[0] + sideLength * cosangle, position[1] + sideLength * sinangle   
        ];

        let indices = [0, 1, 2];

        super(gl, shader, vertices, indices, color, gl.TRIANGLES, indices.length);
    }
}

/**
 * @Class
 * WebGlApp that manages the WebGL context and shapes
 */
class WebGlApp {
    constructor() {
        this.shapes = [];
    }

    initGl() {
        let canvas = document.getElementById('canvas');
        return canvas.getContext('webgl2');
    }

    setViewport(gl, width, height) {
        gl.viewport(0, 0, width, height);
    }

    clearCanvas(gl) {
        let color = hex2rgb('#022851');  // Aggie Blue
        gl.clearColor(color[0], color[1], color[2], 1.0);
        gl.clear(gl.COLOR_BUFFER_BIT);
    }

    addTriangle(gl, shader, position, sideLength) {
        let color = hex2rgb('#FFBF00');  // Aggie Gold
        let triangle = new Triangle(gl, shader, position, color, sideLength);
        this.shapes.push(triangle);
    }

    clearShapes() {
        this.shapes = [];
    }

    render(gl, canvas_width, canvas_height) {
        this.setViewport(gl, canvas_width, canvas_height);
        this.clearCanvas(gl);

        for (let shape of this.shapes) {
            shape.render(gl);
        }
    }
}

export {
    Triangle,
    WebGlApp
};
